def remover_cliente():
    return 0

def remover_livro():
    return 0