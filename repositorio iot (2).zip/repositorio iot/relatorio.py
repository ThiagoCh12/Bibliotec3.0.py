import csv, os
import pesquisar
from datetime import datetime
def relatorio_atrasados():

    emprestimo_csv = open('emprestimo.csv')
    dados_emprestimo = csv.DictReader(emprestimo_csv, delimiter=";")
    os.system('cls') or None
    print("---------------------RELATORIO DE LIVROS ATRASADOS---------------------")
    print(f'{"CPF":15}', f'{"NOME USUARIO":25}', f'{"TITULO":15}', f'{"EMPRESTIMO":10}', f'{"SITUAÇÃO":10}', f'{"DIAS"}')
    for emprestados in dados_emprestimo:
        data_emprestimo = datetime.strptime(emprestados['data_emprestimo'],'%Y-%m-%d')
        data_hoje = datetime.today()
        dias_atrasados = (data_hoje - data_emprestimo).days
        if dias_atrasados >7:
            situacao = 'atrasado'
            print(f'{emprestados["cpf"]:15}', 
                  f'{emprestados["nome_usuario"]:25}',
                  f'{emprestados["titulo_livro"]:15}',
                  f'{emprestados["data_emprestimo"]:15}',
                  f'{situacao:10}',
                  f'{dias_atrasados}')
            
relatorio_atrasados()