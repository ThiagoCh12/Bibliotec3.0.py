import os, csv

def listar_cliente():

    clientes_csv = open('cliente.csv', encoding = 'utf-8')
    dados = csv.DictReader(clientes_csv,delimiter=';')

    os.system('cls') or None
    print('----------------LISTAGEM DE CLIENTES ----------------')
    print(f'{"CPF":15}', f'{"NOME":25}', "RG")
    for clientes in dados:
        print(f'{clientes["cpf":15]}', f'{clientes["nome":25]}', clientes["rg"])
    clientes_csv.close()


def listar_livros():
    
    livros_csv = open('livros.csv', encoding = 'utf-8')
    dados = csv.DictReader(livros_csv,delimiter=';')

    os.system('cls') or None
    print('----------------LISTAGEM DE LIVROS ----------------')
    print(f'{"CODIGO":15}', f'{"TITULO":25}', f'{"AUTOR":15}', f'{"EDITORA":15}', f'{"ANO_LANÇAMENTO":15}')
    for livros in dados:
        print(f'{livros["codigo":15]}', f'{livros["titulo_livro":25]}', f'{livros["autor":15]}',f'{livros["editora":15]}',f'{livros["ano_lancamento":15]}')
    livros_csv.close()


def listar_emprestimos():

    emprestimo_csv = open('emprestimo.csv', encoding = 'utf-8')
    dados = csv.DictReader(emprestimo_csv,delimiter=';')

    os.system('cls') or None
    print('----------------LISTAGEM DE EMPRESTIMOS ----------------')
    print(f'{"CPF":15}', f'{"NOME USUARIO":25}', f'{"CODIGO DO LIVRO":30}', f'{"TITULO DO LIVRO":35}', f'{"DATA EMPRESTIMO":40}')
    for emp in dados:
        print(f'{emp["cpf":15]}', f'{emp["nome_usuario":25]}', f'{emp["codigo_livro":30]}',f'{emp["titulo_livro":35]}',f'{emp["data_emprestimo":40]}')
    emprestimo_csv.close()

    return 0
    #cpf;"nome_usuario";codigo_livro;titulo_livro;data_emprestimo